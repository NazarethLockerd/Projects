
/*
 * Simple class to demonstrate writing JUnit
 */
public class Simple {

	// attributes
	private int value1;
	private int value2;
	
	/**
	 * Default constructor: Initialize v1 and v2 to 0
	 */
	public Simple()
	{
		value1 = 0;
		value2 = 0;
	}
	
    /**
     * Create a SimpleClass with numSides sides<p>
     * pre: v1 >= 0 and v2 >=0<br>
     * post: getValue1() = v1, getValue2() = v2<br>
     * @Throws IllegalArgumentException
     */
	public Simple(int v1, int v2)
	{
		if (v1 < 0 || v2 < 0)
		{
			throw new IllegalArgumentException(" v1 must be greater than 0");
		}
		value1 = v1;
		value2 = v2;
	}
	/**
	 * Add v1 and v2
	 * @return the result of addition
	 */
	public int add()
	{
		return (value1 + value2);
	}
	
	/**
	 * Multiple v1 and v2
	 * @return the result of multiplication
	 */
	public int multiply()
	{
		return (value1 * value2);
	}

	/**
	 * Subtract v1 from v2
	 * @return the result of subtraction
	 */
	public int subtract()
	{
		return (value2 - value1);
	}
	
	/**
	 * Divide v1 by v2
	 * pre: v2 cannot be 0
	 * @Throws IllegalArgumentException
	 * @return the result of division
	 */
	public double division()
	{
		if (value2 == 0)
		{
			throw new IllegalArgumentException(" v2 cannot be 0");
		}
		
		return (value1*1.0 / value2);
	}
	
	public int getValue1() {
		return value1;
	}

	public int getValue2() {
		return value2;
	}

	/**
     * returns true if this SimpleClass and the parameter otherObj are equal<p>
     * pre: none<br>
     * post: return true if the parameter is a SimpleClass object with the same v1 and v2 values as this SimpleClass 
     * @return true if the the two Dice are equal, false otherwise
     */
    public boolean equals(Object otherObj)
    {   
    	boolean result = true;
    	if (otherObj == null)
    		result = false;
    	else if(this == otherObj)
            result = true;
        else if(this.getClass() != otherObj.getClass())
            result = false;
        else
        {   
        	Simple otherClass = (Simple)otherObj;
            result = this.value1 == otherClass.value1;
         }
        return result;
    }


    /**
     * returns a String containing information about this SimpleClass<p>
     * pre: none<br>
     * post: return a String with information about the current state of this SimpleClass
     * @return: A String with the values of v1 and v2
     */
    public String toString()
    {   
    	return "v1=" + getValue1() + " v2=" + getValue2();
    }

	
}

