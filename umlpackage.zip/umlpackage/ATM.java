
package umlpackage;


public class ATM {
    
    private String location;
    private String managedby;

    
    public String getLocation() {
        return location;
    }

   
    public void setLocation(String location) {
        this.location = location;
    }

    
    public String getManagedby() {
        return managedby;
    }

    
    public void setManagedby(String managedby) {
        this.managedby = managedby;
    }
    
        
    public void withdraw() {
        
    }
    
    public void deposit() {
        
    }
    
    public void checkBalance() {
        
    }
}
