
package umlpackage;


public class CheckingAccount extends Account{
    
    
    
    
    public void printType() {
        System.out.println("This is a checking account");
    }
    
    
}
