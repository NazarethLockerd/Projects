function addition(){
//get the inputs num1 and num2

getValues();

sum = (num1) + (num2); //addition
document.getElementById("Sum").innerHTML ="Sum=" + sum;
}

function subtraction(){
getValues();

dif = (num1) - (num2); //subtraction
document.getElementById("Dif").innerHTML ="Dif=" + dif;
}

function multiplication(){
getValues();

product = (num1) * (num2); //multiplication
document.getElementById("Product").innerHTML ="Product=" + product;
}

function division(){
getValues();

div = (num1) / (num2); //division
document.getElementById("Div").innerHTML ="Div=" + div;
}


function modulus(){
getValues();

mod = (num1) % (num2); //modulus
document.getElementById("Mod").innerHTML ="Mod=" + mod;
}

function getValues() {
num1 = document.getElementById("num1").value;
num2 = document.getElementById("num2").value;
num1 = parseInt(num1);
num2= parseInt(num2);
}

function isEven() {
getValues();
if (num1 %2 == 0){
document.getElementById("isEven").innerHTML = "first number is even"
}
else {
document.getElementById("isEven").innerHTML = " first number is odd"
}
if (num2 %2 == 0){
document.getElementById("isOdd").innerHTML = "second number is even"
}
else {
document.getElementById("isOdd").innerHTML = "second  number is odd"
}
}


